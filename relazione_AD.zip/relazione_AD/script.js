const inputField = document.getElementById('cmd-input');
const outputDiv = document.getElementById('output');

// Lista dei comandi validi base
const validCommands = ['help', 'vmware', 'ad-ds', 'utenti', 'clear', 'cls', 'theme', 'color'];

// Gestione Cronologia Comandi
const commandHistory = [];
let historyIndex = -1;

// Mantiene il focus sull'input cliccando ovunque nello schermo
document.addEventListener('click', function() {
    inputField.focus();
});

// Gestione dell'invio e delle frecce direzionali
inputField.addEventListener('keydown', function(e) {
    if (e.key === 'Enter') {
        const fullCmd = inputField.value.trim();
        const cmdLower = fullCmd.toLowerCase();
        
        // Salva nella cronologia se non è vuoto
        if (fullCmd !== '') {
            // Rimuovi eventuale duplicato se è uguale all'ultimo comando inserito
            if (commandHistory[commandHistory.length - 1] !== fullCmd) {
                commandHistory.push(fullCmd);
            }
            historyIndex = commandHistory.length;
        }

        inputField.value = '';
        
        // Stampa il prompt e il comando digitato
        printOutput(`PS C:\\Relazione> ${fullCmd}`);
        
        if (cmdLower !== '') {
            processCommand(cmdLower);
        }
        
        // Scroll verso il basso
        scrollToBottom();
        
    } else if (e.key === 'ArrowUp') {
        e.preventDefault(); // Evita lo scroll della pagina
        if (commandHistory.length > 0 && historyIndex > 0) {
            historyIndex--;
            inputField.value = commandHistory[historyIndex];
        }
    } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        if (commandHistory.length > 0 && historyIndex < commandHistory.length - 1) {
            historyIndex++;
            inputField.value = commandHistory[historyIndex];
        } else {
            historyIndex = commandHistory.length;
            inputField.value = '';
        }
    }
});

function processCommand(fullCmd) {
    // Dividiamo il comando dagli argomenti (es: "theme 1")
    const parts = fullCmd.split(/\s+/);
    const cmd = parts[0];
    const arg = parts[1];

    if (cmd === 'clear' || cmd === 'cls') {
        outputDiv.innerHTML = '';
        return;
    }

    if (cmd === 'theme' || cmd === 'color') {
        // Rimuove tutti i temi
        document.body.className = '';
        document.documentElement.className = '';
        
        let themeName = 'Default (PowerShell Blu)';
        
        if (arg === '1') {
            document.body.classList.add('theme-1');
            document.documentElement.classList.add('theme-1');
            themeName = '1 (Nero CMD)';
        } else if (arg === '2') {
            document.body.classList.add('theme-2');
            document.documentElement.classList.add('theme-2');
            themeName = '2 (Ubuntu Purple)';
        } else if (arg === '3') {
            document.body.classList.add('theme-3');
            document.documentElement.classList.add('theme-3');
            themeName = '3 (Matrix Hacker)';
        } else if (arg === '4') {
            document.body.classList.add('theme-4');
            document.documentElement.classList.add('theme-4');
            themeName = '4 (Retro Ambra)';
        } else if (arg) {
            printOutput(`<span class="error">Tema '${arg}' non trovato. Usa: theme 1, theme 2, theme 3, theme 4, oppure solo 'theme' per il blu di default.</span><br><br>`, true);
            return;
        }

        printOutput(`Colore del terminale impostato su: ${themeName}<br><br>`, true);
        return;
    }

    if (validCommands.includes(cmd)) {
        // Recupera l'HTML nascosto
        const contentElement = document.getElementById(`content-${cmd}`);
        if (contentElement) {
            printOutput(contentElement.innerHTML, true);
        }
    } else {
        // Comando non riconosciuto
        printOutput(`<span class="error">${cmd} : Termine '${cmd}' non riconosciuto come nome di cmdlet, funzione, programma eseguibile o file script. Controllare l'ortografia del nome o verificare che il percorso sia incluso e corretto, quindi riprovare.</span><br><br>`, true);
    }
}

function printOutput(text, isHtml = false) {
    const div = document.createElement('div');
    if (isHtml) {
        div.innerHTML = text;
    } else {
        div.textContent = text;
    }
    outputDiv.appendChild(div);
}

function scrollToBottom() {
    window.scrollTo(0, document.body.scrollHeight);
}

// Funzione globale per i comandi cliccabili
window.executeCommand = function(cmd) {
    // Aggiungi anche i comandi cliccati alla cronologia
    if (commandHistory[commandHistory.length - 1] !== cmd) {
        commandHistory.push(cmd);
    }
    historyIndex = commandHistory.length;
    
    printOutput(`PS C:\\Relazione> ${cmd}`);
    processCommand(cmd);
    scrollToBottom();
    inputField.focus();
};
